-- NGPC: Validate Palette
-- Liste les couleurs de la palette qui NE SONT PAS représentables
-- sur hardware NGPC (les canaux doivent être des multiples de 17)

local function is_ngpc_valid(c)
    return (c.red   % 17 == 0) and
           (c.green % 17 == 0) and
           (c.blue  % 17 == 0)
end

local function closest_ngpc(v)
    local n = math.floor(v / 17 + 0.5)
    if n > 15 then n = 15 end
    return n * 17
end

local spr = app.activeSprite
if not spr then
    app.alert("Aucun sprite actif.")
    return
end

local pal = spr.palettes[1]
local bad = {}
local ok_count = 0

for i = 0, #pal - 1 do
    local c = pal:getColor(i)
    if not is_ngpc_valid(c) then
        table.insert(bad, {
            idx = i,
            r = c.red, g = c.green, b = c.blue,
            r2 = closest_ngpc(c.red),
            g2 = closest_ngpc(c.green),
            b2 = closest_ngpc(c.blue),
        })
    else
        ok_count = ok_count + 1
    end
end

if #bad == 0 then
    app.alert(string.format(
        "Palette valide !\nToutes les %d couleurs sont conformes NGPC hardware.",
        #pal
    ))
    return
end

-- Construire le rapport
local lines = {
    string.format("PALETTE : %d valide(s), %d invalide(s)\n", ok_count, #bad),
    "Index  Actuelle              Corrigée NGPC",
    string.rep("-", 50),
}

for _, e in ipairs(bad) do
    table.insert(lines, string.format(
        "[%3d]  RGB(%3d,%3d,%3d)  →  RGB(%3d,%3d,%3d)",
        e.idx, e.r, e.g, e.b, e.r2, e.g2, e.b2
    ))
end

table.insert(lines, "\nUtilise 'Snap Palette to Hardware Colors' pour corriger.")

app.alert{ title="NGPC Palette Validation", text=table.concat(lines, "\n") }
