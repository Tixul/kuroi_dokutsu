-- NGPC: Export Palette as C Macros
-- Génère le code C pour charger la palette dans le code NGPC
-- Format : ngpc_gfx_set_palette(plane, id, c0, c1, c2, c3)
-- ou tableau de valeurs u16 avec la macro RGB(r4, g4, b4)

local function to_ngpc(v)
    -- 8-bit → 4-bit (arrondi)
    local n = math.floor(v / 17 + 0.5)
    if n > 15 then n = 15 end
    return n
end

local function color_to_u16_hex(c)
    local r = to_ngpc(c.red)
    local g = to_ngpc(c.green)
    local b = to_ngpc(c.blue)
    local u16 = r | (g << 4) | (b << 8)
    return string.format("0x%03X", u16), r, g, b
end

local spr = app.activeSprite
if not spr then
    app.alert("Aucun sprite actif.")
    return
end

local pal = spr.palettes[1]
local n = #pal

-- Déterminer combien de palettes NGPC ça fait (4 couleurs / palette)
local num_palettes = math.ceil(n / 4)

local lines = {
    "/* ===================================================",
    " * Palette NGPC générée depuis Aseprite",
    string.format(" * %d couleurs Aseprite → %d palette(s) NGPC (4 couleurs chacune)", n, num_palettes),
    " *",
    " * Utilisation : chaque palette NGPC a 4 slots (index 0 = transparent)",
    " * ngpc_gfx_set_palette(GFX_SCR1, id, c0, c1, c2, c3)",
    " * ===================================================*/",
    "",
    "/* -- Tableau de couleurs brutes u16 -- */",
    string.format("static const u16 palette_data[%d] = {", n),
}

for i = 0, n - 1 do
    local c = pal:getColor(i)
    local hex, r4, g4, b4 = color_to_u16_hex(c)
    local comma = (i < n - 1) and "," or " "
    table.insert(lines, string.format(
        "    %s%s  /* [%2d] RGB(%2d,%2d,%2d) = RGB8(%3d,%3d,%3d) */",
        hex, comma, i, r4, g4, b4, c.red, c.green, c.blue
    ))
end

table.insert(lines, "};")
table.insert(lines, "")
table.insert(lines, "/* -- Chargement palette par palette (plane = GFX_SCR1 / GFX_SCR2 / GFX_SPR) -- */")
table.insert(lines, "static void load_palette(u8 plane) {")

for pid = 0, num_palettes - 1 do
    local base = pid * 4
    local cs = {}
    for ci = 0, 3 do
        local idx = base + ci
        if idx < n then
            local c = pal:getColor(idx)
            local r4 = to_ngpc(c.red)
            local g4 = to_ngpc(c.green)
            local b4 = to_ngpc(c.blue)
            table.insert(cs, string.format("RGB(%d,%d,%d)", r4, g4, b4))
        else
            table.insert(cs, "RGB(0,0,0)")
        end
    end
    table.insert(lines, string.format(
        "    ngpc_gfx_set_palette(plane, %2d, %s, %s, %s, %s);  /* entrées %d-%d */",
        pid, cs[1], cs[2], cs[3], cs[4], base, base+3
    ))
end

table.insert(lines, "}")

local result = table.concat(lines, "\n")

-- Afficher dans un dialogue (copier-coller)
local dlg = Dialog("NGPC Export C - Copie le code ci-dessous")
dlg:entry{ id="code", label="Code C:", text=result, focus=true }
dlg:button{ id="close", text="Fermer" }
dlg:show()
