-- NGPC: Snap Palette to Hardware Colors
-- Arrondit chaque couleur de la palette aux valeurs exactes NGPC (multiples de 17)
-- La NGPC a 4 bits par canal (0-15), soit 4096 couleurs possibles.
-- En 8 bits Aseprite : les valeurs valides sont 0, 17, 34, 51, 68, 85, 102, 119,
--                      136, 153, 170, 187, 204, 221, 238, 255

local function snap_channel(v)
    -- Arrondi au multiple de 17 le plus proche, clampé à [0, 255]
    local n = math.floor(v / 17 + 0.5)
    if n > 15 then n = 15 end
    if n < 0  then n = 0  end
    return n * 17
end

local spr = app.activeSprite
if not spr then
    app.alert("Aucun sprite actif.")
    return
end

local pal = spr.palettes[1]
local count = 0

app.transaction("Snap to NGPC Colors", function()
    for i = 0, #pal - 1 do
        local c = pal:getColor(i)
        local r = snap_channel(c.red)
        local g = snap_channel(c.green)
        local b = snap_channel(c.blue)
        if r ~= c.red or g ~= c.green or b ~= c.blue then
            pal:setColor(i, Color{ r=r, g=g, b=b, a=c.alpha })
            count = count + 1
        end
    end
end)

app.refresh()

if count == 0 then
    app.alert("Palette déjà conforme aux couleurs NGPC hardware.")
else
    app.alert(string.format(
        "Snap terminé : %d couleur(s) corrigée(s) sur %d.\n\nToutes les couleurs sont maintenant exactes NGPC (12-bit).",
        count, #pal
    ))
end
